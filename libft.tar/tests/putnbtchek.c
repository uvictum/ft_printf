#include "libft.h"

int main()
{
	int i = 0;

	ft_putnbr(i);
	return 0;
}
