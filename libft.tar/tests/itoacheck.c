#include "libft.h"

int	main()
{
	int n = 0;
	char *num = ft_itoa(n);

	printf("%s", num);
	return (0);
}
