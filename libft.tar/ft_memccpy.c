/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vmorguno <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 13:53:19 by vmorguno          #+#    #+#             */
/*   Updated: 2017/11/09 19:34:58 by vmorguno         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memccpy(void *dest, const void *src, int c, size_t n)
{
	unsigned int	i;
	unsigned char	*dst;
	unsigned char	*srs;

	i = 0;
	dst = (unsigned char *)dest;
	srs = (unsigned char *)src;
	while (n >= i)
	{
		dst[i] = srs[i];
		i++;
		if (srs[i] == (unsigned char)c)
			return (&dst[i]);
	}
	return (NULL);
}
